
from langchain_core.prompts import ChatPromptTemplate
import os
from langchain_community.llms import HuggingFaceHub
from langchain_community.utilities import SQLDatabase
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_community.llms import HuggingFaceHub
os.environ["HUGGINGFACEHUB_API_TOKEN"] ='hf_TQECfdVSTRuSw**************************'

template = """You are an intelligent.Based on the table schema below, write a SQL query that would answer the user's question without assigning the variable table_name=products,
                return the result without the datatype for example,the actual output is Decimal('2.16') but i need only as 2.16
{schema}

Question: {question}
SQL Query:"""

template_for_query='''Please provide the response based on the given input which is understood even for laymen .For example, if the input given is Decimal('2.16'),response should be like 2.16.Dont modify or change the value.
                        note:
                            1.Please return the exact output
                         {input} 
                         output:'''
prompt = ChatPromptTemplate.from_template(template)
prompt_query=ChatPromptTemplate.from_template(template_for_query)
llm = HuggingFaceHub(repo_id='mistralai/Mixtral-8x7B-Instruct-v0.1')


from langchain_community.utilities import SQLDatabase
db_url='postgresql+psycopg2://postgres:admin@localhost:5432/sql_qa'
db=SQLDatabase.from_uri(db_url)
schema_info = {
    "productid": "integer",
    "name": "character varying",
    "price": "numeric",
    "discountpercentage": "integer",
    "category": "character varying",
    "quantityinstock": "integer",
    "manufacturedate": "date",
    "priceafterdiscount": "numeric"
}

def get_schema():
    schema = db.get_table_info()

    return schema
def run_query(query):
    return (sql_chain_query.invoke({"input": db.run(query)}))
sql_chain = ( prompt
    | llm.bind(stop=["\nSQLResult:"])
    | StrOutputParser()
)
sql_chain_query = ( prompt_query
    | llm.bind(stop=["\nSQLResult:"])
    | StrOutputParser()
)

def sql_query(msg):
    user_question =msg+',where table name=products'
    query=(sql_chain.invoke({"question": user_question,'schema':schema_info}))
    final=(query[query.index('SQL Query:')+len('SQL Query:'):])
    final=final[final.index('SELECT'):final.index(';')+1]
    output=run_query(final)
    output=output[2:-2].strip(',')
    return (output[output.index('output:')+len('output')+2:output.index('Input')])