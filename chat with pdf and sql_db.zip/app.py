from flask import Flask, render_template, request, jsonify, redirect
from typing_extensions import Concatenate
from PyPDF2 import PdfReader
import shutil
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
import os
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.embeddings.huggingface import HuggingFaceEmbeddings
from langchain.chains.question_answering import load_qa_chain
from langchain_community.llms import HuggingFaceHub

os.environ["HUGGINGFACEHUB_API_TOKEN"] = 'hf_RV**********************************'

app = Flask(__name__)

directory = 'uploads'

if os.path.exists(directory):
    try:
        shutil.rmtree(directory)
        
    except OSError as e:
       0
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)



def count_words_in_pdf(file_path):
    with open(file_path, 'rb') as file:
        pdf_reader = PdfReader(file)
        raw_text = ''
        for i, page in enumerate(pdf_reader.pages):
            content = page.extract_text()
            if content:
                raw_text += content
    return len(raw_text.split())  # Split text into words and count

# Define route to handle the PDF file uplo

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    global document_search

    if request.method == 'POST':
        if 'files[]' not in request.files:
            return redirect(request.url)
        files = request.files.getlist('files[]')
        word_count_total = 0
        for file in files:
            if file.filename == '':
                continue
            filename = file.filename
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            word_count = count_words_in_pdf(file_path)
            word_count_total += word_count


        return render_template('chat.html', word_count_total=word_count_total)
    return render_template('chat.html')

def count_words_in_pdf(file_path):
    with open(file_path, 'rb') as file:
        pdf_reader = PdfReader(file)
        raw_text = ''
        for i, page in enumerate(pdf_reader.pages):
            content = page.extract_text()
            if content:
                raw_text += content
    return len(raw_text.split())  # Split text into words and count
sql_keywords=['name','price','category','quantitystock','manufacturedate','priceafterdiscount','discountpercentage','database']
@app.route("/get", methods=["POST"])
def chat():
    from chatbot import get_Chat_response
    from sql_bot import sql_response

    if request.method == "POST":
        try:
            data = request.get_json()
            print("Received data:", data)
            msg = data.get("msg", "")
            msg=msg.lower()
            if any(keywords in msg for keywords in sql_keywords):
                response =sql_response(msg)
                return jsonify({"response": response})
            elif 'in database' not in msg:
                response =get_Chat_response(msg)
                return jsonify({"response": response})
            else:
                return jsonify({"response": "No message provided."})
        except Exception as e:
            0


if __name__ == '__main__':
    app.run()
